apriori_button = tk.Button(root, text="Apriori", command=run_apriori_algorithm)
# apriori_button.grid(row=1, column=0)